ارفع main.py وbanner.png وrequirements.txt في نفس المجلد.
أضف DISCORD_TOKEN وDISCORD_GUILD_ID في البيئة واضغط تشغيل.
من حساب مالك السيرفر شغّل /setup-mafia وضع حذف كل الرومات في خانة confirm.
يتم تجهيز الرومات الجديدة أولًا ثم حذف الرومات والكاتيجوريات القديمة ورسائلها نهائيًا.
استخدم /mafia-rules لنشر القوانين مع البنر.

في Discord Developer Portal > Bot فعّل Server Members Intent قبل تشغيل الإصدار الجديد.
ارفع main.py وrequirements.txt وbanner.png وcheck.png وcross.png في نفس المجلد.
في Railway ارفع المشروع إلى GitHub ثم اختر Deploy from GitHub repo. أضف متغيري البيئة في Variables وحدد Start Command على python main.py.
إذا الرومات القديمة جاهزة استخدم /mafia-welcome و/gang-system و/mafia-stickers مباشرة.
لا تستخدم /setup-mafia لإضافة المزايا إلى رومات موجودة، فهو أمر إعادة تجهيز وحذف.
يحتاج البوت صلاحية إدارة الرتب وإنشاء تعبيرات السيرفر، ورتبة البوت أعلى من رتب الحضور.
